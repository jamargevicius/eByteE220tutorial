/*   main.cpp for A-testBasicE220Wiring project
        tests ESP32 <--> eByte E220

    Joe Margevicius -- April 2025  
*/

#include <Arduino.h>

//**************************************************************************************
//******************* assignments and constants ****************************************
//**************************************************************************************
// GPIO assignments (usingUART #2 to communicate with eByte)
#define gpio_ESP_RXD2     GPIO_NUM_16
#define gpio_ESP_TXD2     GPIO_NUM_17
#define gpio_eByte_AUX    GPIO_NUM_4    // AUX line from eByte
#define gpio_eByte_M0     GPIO_NUM_32   // M0 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_eByte_M1     GPIO_NUM_33   // M1 line to eByte = RTC GPIO to preserve state later in sleep mode
//#define gpio_onBoardLED   GPIO_NUM_2    // not used in this code: later used to indicate a packet received and passed filter test
#define gpio_module_type  GPIO_NUM_15   // = true for xmitter; = false for rcvr; facilitates code development later

/* modes: (note - different for E22 modules)
  [M1 M0] = [0 0] for Normal mode
  [M1 M0] = [0 1] for WOR Tx
  [M1 M0] = [1 0] for WOR Rx
  [M1 M0] = [1 1] for Configuration mode, and Sleep mode
*/

// eByte Register I/O:  for normal registers, command C0 to write, C1 to read (see others below)

// defaults at power-up: 
//  UART: 9600, 8N1 parity;  Air rate: 2400bps; sub-packet max length: 200bytes; 
//  RSSI support: disabled; Tx Power: 22dbm (0.16 watts); WOR_CYCLE: (no default specified in manual)

// E220 eByte registers (note - different from E22 modules)
#define REG_MODULE_ADDR_H       0x00  // specifies addr of unit: e.g contents = 0x0102 = 258
#define REG_MODULE_ADDR_L       0x01
#define REG0                    0x02  // multiple settings ("Switches")
#define REG1                    0x03  // multiple settings ("Switches")
#define REG2_RF_CHAN            0x04  
#define REG3                    0x05  // multiple settings ("Switches")
#define REG_CRYPT_H             0x06
#define REG_CRYPT_L             0x07

// I/O commands
#define WRITE_REG_CMD                 0xC0  // a command for example: {WRITE_REG_CMD, REGtoWrite, 0x01, contentsToWrite}; 
#define READ_REG_CMD                  0xC1  
#define WRITE_TEMP_REG_CMD            0xC2

// Register Switches: REG 0,1,2,3

  // REG0 content: "Switches" 
    // NOTE: MUST bit OR these 3 categories e.g. (UART_RATE_9600 | EBYTE_UART_PARITY_8N1 | AIR_RATE_9600) 
    // UART speeds - bits/second
#define EBYTE_UART_RATE_1200          0x00      
#define EBYTE_UART_RATE_2400          0x20      
#define EBYTE_UART_RATE_4800          0x40      
#define EBYTE_UART_RATE_9600          0x60      // default 
#define EBYTE_UART_RATE_19200         0x80      
#define EBYTE_UART_RATE_38400         0xA0      
#define EBYTE_UART_RATE_57600         0xC0
#define EBYTE_UART_RATE_115200        0xE0
    // UART 9 bit format
#define EBYTE_UART_PARITY_8N1         0x00      // default (see manual for other rarer parity options)
#define EBYTE_UART_PARITY_8O1         0x08
#define EBYTE_UART_PARITY_8E1         0x10
//#define EBYTE_UART_PARITY_8N1         0x18         // same as default
    // Tx/Rx RF Air rate - bits/second
//#define AIR_RATE_2400           0x00          // same as default -- was 300 in E22, but didn't work
//#define AIR_RATE_2400           0x01          // same as default -- was 1200 in E22, but didn't work
#define AIR_RATE_2400           0x02      // default           
#define AIR_RATE_4800           0x03
#define AIR_RATE_9600           0x04
#define AIR_RATE_19200          0x05
#define AIR_RATE_38400          0x06
#define AIR_RATE_62500          0x07

  // REG1 content: "Switches"
     // NOTE: MUST OR the 3 categories e.g. (PKT_LENGHT_128 OR RSSI_READ_ENABLE OR XMIT_PWR_30DBM)
    // quantizing size of each packet in long message; data chopped into this sized packets (both Tx & Rx need to be the same) 
#define PKT_LENGTH_200          0x00  // default
#define PKT_LENGTH_128          0x40
#define PKT_LENGTH_64           0x80
#define PKT_LENGTH_32           0xA0
    // Rcv Signal Strenght Indicator; enable/disable reading of RSSI. Use command (C0 C1 C2 C3) to read it (: (dBm = -RSSI/2)
    // in the command, specify reg 0x00 for current RSSI; previous = reg 0x01 
#define RSSI_READ_DISABLE       0x00   // default
#define RSSI_READ_ENABLE        0x20  
    // Transmit power options; Transmit power in dbm; lowest current = highest power (non-linear)
#define XMIT_PWR_22DBM          0x00   // default (0.16 watts)
#define XMIT_PWR_17DBM          0x01
#define XMIT_PWR_13DBM          0x02
#define XMIT_PWR_10DBM          0x03

  // REG2_RF_CHAN content
     // RF channel select = 0x00 to 0x50 (0 to 80) --- RF Freq = 850.125Mhz + 1Mhz x Chan Number (e.g. 0x28 = chan 40 --> freq = 890.125Mhz)

  // REG3 content: "Switches"
    // NOTE: MUST OR these 6 categories (default is 0, so only need to OR the ones to be changed from default) eg. WOR_CYCLE_2500MS - rest is default
#define DISABLE_RSSI_DATA_OUT   0x00  // default
#define ENABLE_RSSI_DATA_OUT    0x80     // enables sending RSSI at end of Rx Data out on Serial Port
#define PKT_ADR_CHAN_IGNORE     0x00  // default
#define PKT_ADR_CHAN_READ       0x40     // Filters by checking received packed Address and Channel Number
#define MONITOR_XMISSION_OFF    0x00  // default
#define MONITOR_XMISSION_ON     0x10     // not clear how this is done: spec says "monitor before xmission" to avoid interference ... but how "before"?
    // WOR cycle period options; this is the period of Wake On Receive (WOR) cycle (pulse is always 250uSec)
#define WOR_CYCLE_500MS         0x00  
#define WOR_CYCLE_1000MS        0x01
#define WOR_CYCLE_1500MS        0x02
#define WOR_CYCLE_2000MS        0x03 
#define WOR_CYCLE_2500MS        0x04
#define WOR_CYCLE_3000MS        0x05
#define WOR_CYCLE_3500MS        0x06
#define WOR_CYCLE_4000MS        0x07

//**************************************************************************************
//********************************* functions ******************************************
//**************************************************************************************
void eByteE220WriteReadMemory(byte REGtoWrite, byte contentsToWrite, int printResponse){
    // Configuration Mode to access registers: M1 M0 = 1 1 for Configuration mode
  digitalWrite(gpio_eByte_M0, HIGH);  
  digitalWrite(gpio_eByte_M1, HIGH);  
  //Serial.printf("\njust put into Config mode [1 1]: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
  delay(100);
  
  byte commandToSend[] = {WRITE_REG_CMD, REGtoWrite, 0x01, contentsToWrite};  // write to just 1 address
  Serial2.write(commandToSend, sizeof(commandToSend));

  delay(100); // delay needed to wait for eByte response and Serial2 being available
  for (int i=0; i<4; i++){
    while(!Serial2.available()){Serial.print("x"); delay(100);} // wait for a character ... WAIT HERE as a Transmitter !
    int incomingByte = Serial2.read();
    if(printResponse){Serial.print(incomingByte,HEX); Serial.print(' ');}
  }
  if(printResponse){Serial.printf(" = response. Expect (C1 %x 1 %x)", REGtoWrite, contentsToWrite);}
  
    // put back into Normal Mode: M1 M0 = 0 0 for Normal mode
  digitalWrite(gpio_eByte_M0, LOW);   
  digitalWrite(gpio_eByte_M1, LOW);   
  delay(100);  // delay 100mS after mode change 
  //Serial.printf("\nnow in Normal mode: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
}

//**************************************************************************************
//********************************* setup ***********************************************
//**************************************************************************************
void setup() {
  Serial.begin(115200); // ESP32 programming serial port
  Serial2.begin(9600, SERIAL_8N1, gpio_ESP_RXD2, gpio_ESP_TXD2); // eByte programming serial port - powers up at 9600baud, 8N1 parity
  delay(100);  // delay necessary (otherwise printout misses first I/O accesses; Serial ports stabalizing? ) 
    
  pinMode(gpio_eByte_M0, OUTPUT);
  pinMode(gpio_eByte_M1, OUTPUT); 
  pinMode(gpio_eByte_AUX, INPUT);
  pinMode(gpio_module_type, INPUT);

  }

//**************************************************************************************
//********************************* main (loop()) ***********************************************
//**************************************************************************************
void loop() { 
  //Serial.printf("\nFYI only - wiring check: reading GPIO 15 = %d (should be 1 if Tx and 0 if Rx)\n", digitalRead(gpio_transmitter));
  Serial.println("\nFYI -- wiring check: ...");
  if(digitalRead(gpio_module_type) == 1){Serial.println("this is a TRANSMITTER");}
  else if (digitalRead(gpio_module_type) == 0){Serial.println("this is a RECEIVER");}

  Serial.print("\nnow will write to 9 control memory locations, then read response\n");

  Serial.print("\nREG_MODULE_ADDR_H : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_H,0x01,1);  // specify addr of unit:  0x0102 = 258
  Serial.print("\nREG_MODULE_ADDR_L : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_L,0x02,1);  
  Serial.print("\nREG0 : "); eByteE220WriteReadMemory(REG0,0x64,1);  // 9600baud, 8N1 protocol, 9600 bps air rate (300 and 1200 not available)
  Serial.print("\nREG1 : "); eByteE220WriteReadMemory(REG1,0x00,1);  // defaults: 240 byte subpackt length, disable read of RSSI, Tx power = max = 30dbm
  Serial.print("\nREG2_RF_CHAN : "); eByteE220WriteReadMemory(REG2_RF_CHAN,0x32,1);  // specify chan 50 (0x32), so that RF freq = 900.125Mhz (850.125M + 1M * chan #)
  Serial.print("\nREG3 : "); eByteE220WriteReadMemory(REG3,0x00,1);  // defaults: enable send RSSI with rcvd pkt, etc ... see spec
  Serial.print("\nREG_CRYPT_H : "); eByteE220WriteReadMemory(REG_CRYPT_H,0x00,1);  // encryption bytes (will always read 0; used to encrypt data)
  Serial.print("\nREG_CRYPT_H : "); eByteE220WriteReadMemory(REG_CRYPT_H,0x00,1);  

  Serial.println("\n\nthe end of a loop ... will wait 5 seconds before doing it again");
  Serial.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"); 
  delay(5000);
}

/*   this is what should appear in the terminal (for a board wired as Rx)  

FYI -- wiring check: ...
this is a TRANSMITTER

now will write to 9 control memory locations, then read response

REG_MODULE_ADDR_H : C1 0 1 1  = response. Expect (C1 0 1 1)
REG_MODULE_ADDR_L : C1 1 1 2  = response. Expect (C1 1 1 2)
REG0 : C1 2 1 64  = response. Expect (C1 2 1 64)
REG1 : C1 3 1 0  = response. Expect (C1 3 1 0)
REG2_RF_CHAN : C1 4 1 32  = response. Expect (C1 4 1 32)
REG3 : C1 5 1 0  = response. Expect (C1 5 1 0)
REG_CRYPT_H : C1 6 1 0  = response. Expect (C1 6 1 0)
REG_CRYPT_H : C1 6 1 0  = response. Expect (C1 6 1 0)

the end of a loop ... will wait 5 seconds before doing it again

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/