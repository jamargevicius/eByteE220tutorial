/*   main.cpp for project: B-testNormalTxRx 
        tests ESP32 <--> eByte in Normal Mode; sends/receives data in Normal mode
        One code for both Tx and Rx (senses level of GPIO 15 = gpio_transmitter put to +3.3V  1 if transmitter, put to Gnd if receiver )

    Joe Margevicius - April 2025
*/

#include <Arduino.h>

//**************************************************************************************
//******************* assignments and constants ****************************************
//**************************************************************************************
// GPIO assignments (usingUART #2 to communicate with eByte)
#define gpio_ESP_RXD2     GPIO_NUM_16
#define gpio_ESP_TXD2     GPIO_NUM_17
#define gpio_eByte_AUX    GPIO_NUM_4    // AUX line from eByte
#define gpio_eByte_M0     GPIO_NUM_32   // M0 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_eByte_M1     GPIO_NUM_33   // M1 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_onBoardLED   GPIO_NUM_2    // used to indicate a packet received and passed filter test
#define gpio_module_type  GPIO_NUM_15  // (not used in this code) = true for xmitter; = false for rcvr; facilitates code development later

 // eByte registers  --- see project testBasicE220Wiring for more complete info on registers of eByte
#define REG_MODULE_ADDR_H       0x00  // specify addr of unit:  0x0102 = 258
#define REG_MODULE_ADDR_L       0x01

#define REG0                    0x02  // specify the following 3 "switches" in REG0
#define EBYTE_UART_RATE_9600    0x60      // default
#define EBYTE_UART_PARITY_8N1   0x00      // default
#define AIR_RATE_9600           0x04
#define REG0_Setup              EBYTE_UART_RATE_9600 | EBYTE_UART_PARITY_8N1 | AIR_RATE_9600

#define REG2_RF_CHAN            0x04  // = RF channel select (# 0 to #80) --- RF Freq = 850.125Mhz + 1Mhz x Chan Number (e.g. chan 4 --> freq = 854.125Mhz

 // I/O commands
#define WRITE_REG_CMD           0xC0

  // data to send by Tx
char TxMessage[] = "Hello ... how are you doing today?"; 
int TxMessageLength = sizeof(TxMessage);
  // data to send by Rx
char RxAck[] = "ACK";
int RxAckLength = sizeof(RxAck);


//**************************************************************************************
//********************************* functions ***********************************************
//**************************************************************************************
void eByteE220WriteReadMemory(byte REGtoWrite, byte contentsToWrite, int printResponse){
    // Configuration Mode to access registers: M1 M0 = 1 1 for Configuration mode
  digitalWrite(gpio_eByte_M0, HIGH);  
  digitalWrite(gpio_eByte_M1, HIGH);  
  //Serial.printf("\njust put into Config mode [1 1]: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
  delay(100);
  
  byte commandToSend[] = {WRITE_REG_CMD, REGtoWrite, 0x01, contentsToWrite};  // write to just 1 address
  Serial2.write(commandToSend, sizeof(commandToSend));

  delay(100); // delay needed to wait for eByte response and Serial2 being available
  for (int i=0; i<4; i++){
    while(!Serial2.available()){Serial.print("x"); delay(100);} // wait for a character ... WAIT HERE as a Transmitter !
    int incomingByte = Serial2.read();
    if(printResponse){Serial.print(incomingByte,HEX); Serial.print(' ');}
  }
  if(printResponse){Serial.printf(" = response. Expect (C1 %x 1 %x)", REGtoWrite, contentsToWrite);}
  
    // put back into Normal Mode: M1 M0 = 0 0 for Normal mode
  digitalWrite(gpio_eByte_M0, LOW);   
  digitalWrite(gpio_eByte_M1, LOW);   
  delay(100);  // delay 100mS after mode change 
  //Serial.printf("\nnow in Normal mode: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
}

void initializeDevice(){ // write to 4 registers
  Serial.print("\n ... initializing eByte - write to 4 memory locations\n");
  Serial.print("\nREG_MODULE_ADDR_H : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_H,0x01,1); // specify module addr: 0x12
  Serial.print("\nREG_MODULE_ADDR_L : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_L,0x02,1); 
  Serial.print("\nREG0 : "); eByteE220WriteReadMemory(REG0,REG0_Setup,1);  
  Serial.print("\nREG2_RF_CHAN : "); eByteE220WriteReadMemory(REG2_RF_CHAN,0x28,1);  // specify RF chan = 0x28 = Chan 40
    // note: using defaults of REG1 and REG3 -- see A-testBasicE220Wiring for more details if interested
}
  
void blinkOnBoardLED(int numberOfBlinks){
  if (numberOfBlinks == 1){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
  else if (numberOfBlinks == 2){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200); 
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
  else if (numberOfBlinks == 3){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200);
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200);
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
}

//**************************************************************************************
//********************************* setup ***********************************************
//**************************************************************************************

void setup() {
  Serial.begin(115200); // ESP32 programming serial port
  Serial2.begin(9600, SERIAL_8N1, gpio_ESP_RXD2, gpio_ESP_TXD2); // eByte programming serial port - powers up at 9600baud, 8N1 parity
  
  pinMode(gpio_eByte_AUX, INPUT);
  pinMode(gpio_eByte_M0, OUTPUT);
  pinMode(gpio_eByte_M1, OUTPUT);
  pinMode(gpio_onBoardLED, OUTPUT);
  pinMode(gpio_module_type, INPUT);
     
  initializeDevice();
  
 
    
}

//**************************************************************************************
//********************************* main (loop) ****************************************
//**************************************************************************************
void loop() {  
  // **************************** TRANSMITTER *********************************************
  // send message every ~5 seconds, but wait for ACK back from Rx
    // ************************************************************************************
  if(digitalRead(gpio_module_type) == true){   
    Serial.println("\n\nSetting up the TRANSMITTER to send 1 message, then wait for ACK from receiver");
    Serial.printf("now will transmit %d bytes\n", TxMessageLength);
    Serial2.write(TxMessage, sizeof(TxMessage));
    blinkOnBoardLED(1); // blink LED 1x to indicate a packet was sent out
    Serial.println("message sent");

     // now wait for the Rx to send an ACK
    char incomingByte[RxAckLength] = {}; // zero the array;
    //char incomingByte[RxAckLength]; // zero the array;
    for (int i=0; i<RxAckLength; i++) {  
      while(!Serial2.available()){ // wait for a character ... WAIT HERE as a Transmitter !
          Serial.print(".");
          delay(1000);}
      //Serial.println("read a character");
      incomingByte[i] = Serial2.read();}
    blinkOnBoardLED(3); // blink 3x to indicate an ACK was received
    Serial.printf("\n%s (received by Tx; sent from Rx after received message)\n", incomingByte);
    delay(4000); // delay 4 seconds before sending another packet
  }
  
  
  // **************************** RECEIVER *********************************************
  // wait for a packet, then send an ACK back to Tx if packet is good
  // ************************************************************************************
  if (digitalRead(gpio_module_type) == false){ 
    Serial.println("\n\nSetting up the RECEIVER to accept 1 message, then if good, send an ACK to the transmitter");
    char incomingByte[TxMessageLength] = {}; // zero the array; 
    for (int i=0; i<TxMessageLength; i++) {  
      while(!Serial2.available()){ // wait for a character ... WAIT HERE as a Receiver !
          Serial.print(".");
          delay(1000);}
      incomingByte[i] = Serial2.read();
    }
    Serial.printf("\npacket that was sent by xmitter was: %s\n", TxMessage);
    Serial.printf("packet just received by rcvr is:     %s\n", incomingByte);
        
      //*********** do a little filtering - verify that the packet is somewhat valid ******** */
    const char *dataPointer = incomingByte;
    if(strstr(dataPointer,"Hello ... how are you doing today?") != NULL){  //comparing 2 strings
      Serial.println("found complete message: \"Hello ... how are you doing today?\"");  // now blink the onBoard LED
      blinkOnBoardLED(2); // blink LED 2x to indicate a good packet was
      Serial.println("\nwill now send Ack to Tx");
      //delay(200);
      Serial2.write(RxAck, sizeof(RxAck));
      Serial.println("just sent ACK");
    }
    else {Serial.println("didn't find pattern");}
  }
}
   
/***** this is what should appear in the TRANSMITTER terminal *** 
 ... initializing eByte - write to 4 memory locations
C1 0 1 1  = response. Expect (C1 0 1 1)
C1 1 1 2  = response. Expect (C1 1 1 2)
C1 3 1 64  = response. Expect (C1 3 1 64)
C1 5 1 7  = response. Expect (C1 5 1 7)


Setting up the TRANSMITTER to send 1 message, then wait for ACK from receiver
now will transmit 35 bytes
message sent
..
ACK (received by Tx; sent from Rx after received message)

Setting up the TRANSMITTER to send 1 message, then wait for ACK from receiver
now will transmit 35 bytes
message sent
.
ACK (received by Tx; sent from Rx after received message)

*********/

/******** this is what should appear in the RECEIVER terminal *****  
 ... initializing eByte - write to 4 memory locations

REG_MODULE_ADDR_H : C1 0 1 1  = response. Expect (C1 0 1 1)
REG_MODULE_ADDR_L : C1 1 1 2  = response. Expect (C1 1 1 2)
REG0 : C1 2 1 64  = response. Expect (C1 2 1 64)
REG2_RF_CHAN : C1 4 1 28  = response. Expect (C1 4 1 28)

Setting up the RECEIVER to accept 1 message, then if good, send an ACK to the transmitter
...
packet that was sent by xmitter was: Hello ... how are you doing today?
packet just received by rcvr is:     Hello ... how are you doing today?
found complete message: "Hello ... how are you doing today?"

will now send Ack to Tx

Setting up the RECEIVER to accept 1 message, then if good, send an ACK to the transmitter
......
packet that was sent by xmitter was: Hello ... how are you doing today?
packet just received by rcvr is:     Hello ... how are you doing today?
found complete message: "Hello ... how are you doing today?"

will now send Ack to Tx

***********/