/*   main.cpp for project: D-testWORwithACK
        tests ESP32 <--> eByte in WOR (Wake On Receive) Mode: 
         -- for message: Rx in 1 second WOR cycle while Tx in 4 second WOR cycle (Tx sends 4+ second packet; Rx checks every 1 second)
         -- both in Normal mode for ACK send/receive
         -- implements ACK'ing by the receiver, and retries by the transmitter if it doesn't get an ACK
         -- includes an OLED for reporting number of transmissions and number of errors

    Joe Margevicius - April 2025 
*/

#include <Arduino.h>

//**************************************************************************************
//********************************* constants and assignments **************************
//**************************************************************************************
// GPIO assignments (usingUART #2 to communicate with eByte)
#define gpio_ESP_RXD2     GPIO_NUM_16
#define gpio_ESP_TXD2     GPIO_NUM_17
#define gpio_eByte_AUX    GPIO_NUM_4    // AUX line from eByte
#define gpio_eByte_M0     GPIO_NUM_32   // M0 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_eByte_M1     GPIO_NUM_33   // M1 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_onBoardLED   GPIO_NUM_2    // used to indicate a packet received and passed filter test
#define gpio_module_type  GPIO_NUM_15   // true for xmitter; = false for rcvr; facilitates code development later

// E220 eByte registers (note - different from E22 modules)
#define REG_MODULE_ADDR_H       0x00  // specifies addr of unit ... i.e. 0x0001
#define REG_MODULE_ADDR_L       0x01

#define REG0                    0x02  // specify the following 3 "switches" in REG0
#define EBYTE_UART_RATE_9600    0x60      // default
#define EBYTE_UART_PARITY_8N1   0x00      // default
#define AIR_RATE_9600           0x04
#define REG0_Setup              EBYTE_UART_RATE_9600 | EBYTE_UART_PARITY_8N1 | AIR_RATE_9600

 // REG1 - using defaults: max RF power out = 158 mWatts  (E22 module had max = 1 Watt)
#define REG2_RF_CHAN            0x04  // = RF channel select (# 0 to #80) --- RF Freq = 850.125Mhz + 1Mhz x Chan Number (e.g. chan 4 --> freq = 854.125Mhz

#define REG3                    0x06  // needed for WOR implementation
#define WOR_CYCLE_1000MS        0x01

 // I/O commands
#define WRITE_REG_CMD           0xC0

/* modes: (note - different for E22 modules)
  [M1 M0] = [0 0] for Normal mode
  [M1 M0] = [0 1] for WOR Tx
  [M1 M0] = [1 0] for WOR Rx
  [M1 M0] = [1 1] for Configuration mode, and Sleep mode
*/

char TxMessage[] = "Hello ... how are you doing today?"; 
int TxMessageLength = sizeof(TxMessage);
char RxAck[] = "ACK";
int RxAckLength = sizeof(RxAck);

//**************************************************************************************
//********************************* functions ******************************************
//**************************************************************************************
void eByteE220WriteReadMemory(byte REGtoWrite, byte contentsToWrite, int printResponse){
    // Configuration Mode to access registers: M1 M0 = 1 1 for Configuration mode
  digitalWrite(gpio_eByte_M0, HIGH);  
  digitalWrite(gpio_eByte_M1, HIGH);  
  //Serial.printf("\njust put into Config mode [1 1]: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
  delay(100);
  
  byte commandToSend[] = {WRITE_REG_CMD, REGtoWrite, 0x01, contentsToWrite};  // write to just 1 address
  Serial2.write(commandToSend, sizeof(commandToSend));

  delay(100); // delay needed to wait for eByte response and Serial2 being available
  for (int i=0; i<4; i++){
    while(!Serial2.available()){Serial.print("x"); delay(100);} // wait for a character ... WAIT HERE as a Transmitter !
    int incomingByte = Serial2.read();
    if(printResponse){Serial.print(incomingByte,HEX); Serial.print(' ');}
  }
  if(printResponse){Serial.printf(" = response. Expect (C1 %x 1 %x)", REGtoWrite, contentsToWrite);}
  
    // put back into Normal Mode: M1 M0 = 0 0 for Normal mode
  digitalWrite(gpio_eByte_M0, LOW);   
  digitalWrite(gpio_eByte_M1, LOW);   
  delay(100);  // delay 100mS after mode change 
  //Serial.printf("\nnow in Normal mode: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
}

void initializeDevice(){ // write to 4 registers
  Serial.print("\n ... initializing eByte - write to 4 memory locations\n");
  Serial.print("\nREG_MODULE_ADDR_H : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_H,0x01,1); // specify module addr: 0x12
  Serial.print("\nREG_MODULE_ADDR_L : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_L,0x02,1); 
  Serial.print("\nREG0 : "); eByteE220WriteReadMemory(REG0,REG0_Setup,1);     // 9600 bps air rate specified (300 and 1200 not available); rest is default: serial port - 9600baud, 8N1 protocol
  Serial.print("\nREG2_RF_CHAN : "); eByteE220WriteReadMemory(REG2_RF_CHAN,0x28,1);  // specify RF chan = 0x28 = Chan 40
    // note: using defaults of REG1 -- see A-testBasicE220Wiring for more details if interested
}
  
void blinkOnBoardLED(int numberOfBlinks){
  if (numberOfBlinks == 1){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
  else if (numberOfBlinks == 2){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200); 
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
  else if (numberOfBlinks == 3){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200);
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200);
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
}

void putInNormal_mode(){// used by both Tx and Rx to switch from WOR to Normal ... [M1 M0] = [0 0]
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" n1 "); delay(10);} // wait for possibly still being in WOR mode
  digitalWrite(gpio_eByte_M1, LOW);
  digitalWrite(gpio_eByte_M0, LOW);
  delay(100); // delay necessary after AUX goes hi before can do anything, but check to be sure AUX is hi
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" n2 "); delay(10);} 
  Serial.println("unit now in Normal Mode");
}

void putInWOR_Tx_mode_1second(){   // [M1 M0] = [0 1] for WOR Tx
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" TxW1_1 "); delay(10);} // wait for possibly still being in WOR mode
   //Serial.println("\n\nsetup for WOR_Transmitter and 2 second WOR cycle");
  eByteE220WriteReadMemory(REG3, WOR_CYCLE_1000MS,0); // returns with [M1 M0] = [0 0]
   // enable this config: switch to WOR mode for the transmitter: M1 M0: 0 0 
   // digitalWrite(gpio_eByte_M1, LOW); // -- not necessary; M1 is already 0
  digitalWrite(gpio_eByte_M0, HIGH);
  delay(100); // delay necessary after AUX goes hi before can do anything, but check to be sure AUX is hi
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" TxW1_2 "); delay(10);} 
  Serial.println("unit now in WOR_Tx Mode 1 second cycle mode");
}

void putInWOR_Rx_mode_1second(){   // [M1 M0] = [1 0] for WOR Rx
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" RxW1_1 "); delay(10);} // wait for possibly still being in WOR mode
    //Serial.println("\n\nsetup for WOR_Receiver and 1 second WOR cycle");
  eByteE220WriteReadMemory(REG3, WOR_CYCLE_1000MS,0); // returns with [M1 M0] = [0 0]
   // enable this config: switch to WOR mode for the receover: M1 M0: 1 0 
  digitalWrite(gpio_eByte_M1, HIGH); 
   // digitalWrite(gpio_eByte_M0, LOW); // -- not necessary; M0 is already 0
  delay(100); // delay a little before continuing after a mode switch
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" RxW1_2 "); delay(10);}
  Serial.printf("\nunit now in WOR_Rx 1 second cycle Mode");
}


//**************************************************************************************
//********************************* setup ***********************************************
//**************************************************************************************
void setup() {
  Serial.begin(115200); // ESP32 programming serial port
  Serial2.begin(9600, SERIAL_8N1, gpio_ESP_RXD2, gpio_ESP_TXD2); // eByte programming serial port - powers up at 9600baud, 8N1 parity
  delay(1000); // delay for time to manually bring up terminal

  pinMode(gpio_eByte_AUX, INPUT_PULLUP);  // pullup not really necessary
  pinMode(gpio_eByte_M0, OUTPUT);
  pinMode(gpio_eByte_M1, OUTPUT);
  pinMode(gpio_onBoardLED, OUTPUT);
  pinMode(gpio_module_type, INPUT);

  digitalWrite(gpio_onBoardLED, LOW);  // start with LED off; ---> turn on but keep on if an error

  initializeDevice(); // configure RF address, channel, power; configure serial2 port -  ends up in Normal mode
   
  if(digitalRead(gpio_module_type) == false){   // configure Receiver into 1 second WOR mode
    putInWOR_Rx_mode_1second();  
  }
  if(digitalRead(gpio_module_type) == true){   // configure Transmitter into 1 second WOR mode
    putInWOR_Tx_mode_1second();  // note that the Tx uses a 1 second WOR cycle, and Rx uses a 1 second 
  }
}
   

// **************************************************************************************
// ********************************* main (loop) ****************************************
// **************************************************************************************
void loop() {  
  // **************************** TRANSMITTER *********************************************
  if(digitalRead(gpio_module_type) == true){ 
    Serial.printf("\nwill transmit %d bytes now in WOR_1 second mode - message is: %s\n", TxMessageLength, TxMessage);
    Serial2.write(TxMessage, sizeof(TxMessage));
      
    blinkOnBoardLED(1); // blink onBoard blue LED 1x (on for 200 mSec)
    delay(1200); // before changing modes, wait ~1.4 seconds for the packet to go out and eByte to be quiet
    putInNormal_mode();
    
     // ********************** ACK section -- TX waits for ACK ***********************
    char incomingByteACK[RxAckLength] = {}; // zero the array; 
    for (int i=0; i<RxAckLength; i++) {  
      while(!Serial2.available()){ // wait for a character ... WAIT HERE !
          Serial.print(".");
          delay(10);}
      incomingByteACK[i] = Serial2.read();}
    Serial.printf("\n%s (received by Tx; sent from Rx after received message)\n", incomingByteACK);
    
    const char *dataPointerACK = incomingByteACK;    
    if(strstr(dataPointerACK,"ACK") != NULL){  //comparing 2 strings
      Serial.printf("\nfound ACK: %s received by Tx from Rx after received message)\n", incomingByteACK);
      blinkOnBoardLED(3);}
    else {
      delay(1000); // equivalent delay as blinking LED 3x
      Serial.printf("ACK not found: %s received by Tx from Rx after received message)\n", incomingByteACK);
    }

    putInWOR_Tx_mode_1second(); // return to WOR_1 second mode to do another transmission
    Serial.println("will wait 3 seconds before transmitting a packet again (= 1 sec LED blinking + 2 sec delay)");
    delay(1000); // delay 1 second before looping to send a message in 1sec WOR again
  }
  
  // **************************** RECEIVER *********************************************
  else if(digitalRead(gpio_module_type) == false){   // Rx is in WOR_1sec mode at this point - start by waiting for packet from Tx
    char incomingByteMessage[TxMessageLength] = {}; // zero the array; 
    for (int i=0; i<TxMessageLength; i++) {  
      while(!Serial2.available()){ // wait for a character ... WAIT HERE !
          Serial.print(".");
          delay(10);}
      incomingByteMessage[i] = Serial2.read();}
    Serial.printf("\n%s (received by Rx)\n", incomingByteMessage);
    
     //*********** do filtering - verify that the packet is valid ******** */
    const char *dataPointer = incomingByteMessage;
    if(strstr(dataPointer,"Hello ... how are you doing today?") != NULL){  //comparing 2 strings
      Serial.println("found complete message: \"Hello ... how are you doing today?\"");  // now blink the onBoard LED
      blinkOnBoardLED(2); // blink LED 2x to indicate a good packet was received
      
      // ********************** ACK section - RX sends ACK ***********************
      Serial.println("\nwill now send Ack to Tx");

      putInNormal_mode();  // send ACK in normal mode (less error prone)
      Serial2.write(RxAck, sizeof(RxAck));
      delay(100); //must wait until eByte gets entire word before changing modes
        // note: although the ACk is only ~400 uSec long, once a Serial2 msg is sent to eByte, 
        //  nothing can be changed in the eByte for at least 100 mSec.  
      Serial.println(" ... ACK sent");
    }
    else {
      Serial.print("packet is bad -- no ACK sent; Tx waits forever --- end of test\n");
      digitalWrite(gpio_onBoardLED, HIGH);  // keep LED on ---- SYSTEM STOPS HERE; Tx waits forever
      delay(600); // equivalent delay as blinking LED 2x
    }

    putInWOR_Rx_mode_1second();  // put back in 1 second WOR cycle, ready to receive WOR packet from Tx
    Serial.println("\nwill start looking for next packet\n");
  }
}  // end of loop()

/*   this is what should appear in the TRANSMITTER terminal  
 ... initializing eByte - write to 4 memory locations

REG_MODULE_ADDR_H : C1 0 1 1  = response. Expect (C1 0 1 1)
REG_MODULE_ADDR_L : C1 1 1 2  = response. Expect (C1 1 1 2)
REG0 : C1 2 1 64  = response. Expect (C1 2 1 64)
REG2_RF_CHAN : C1 4 1 28  = response. Expect (C1 4 1 28)unit now in WOR_Tx Mode 1 second cycle mode

will transmit 35 bytes now in WOR_1 second mode - message is: Hello ... how are you doing today?
unit now in Normal Mode
.....................
ACK (received by Tx; sent from Rx after received message)

found ACK: ACK received by Tx from Rx after received message)
unit now in WOR_Tx Mode 1 second cycle mode
will now wait 3 seconds before transmitting a packet again (= 1 sec LED blinking + 2 sec delay)

will transmit 35 bytes now in WOR_1 second mode - message is: Hello ... how are you doing today?
unit now in Normal Mode
*/

/*   this is what should appear in the RECEIVER terminal  
 ... initializing eByte - write to 4 memory locations

REG_MODULE_ADDR_H : C1 0 1 1  = response. Expect (C1 0 1 1)
REG_MODULE_ADDR_L : C1 1 1 2  = response. Expect (C1 1 1 2)
REG0 : C1 2 1 64  = response. Expect (C1 2 1 64)
REG2_RF_CHAN : C1 4 1 28  = response. Expect (C1 4 1 28)
unit now in WOR_Rx 1 second cycle Mode.......
Hello ... how are you doing today? (received by Rx)
found complete message: "Hello ... how are you doing today?"

will now send Ack to Tx
unit now in Normal Mode
 ... ACK sent

unit now in WOR_Rx 1 second cycle Mode
will start looking for next packet

....
Hello ... how are you doing today? (received by Rx)
found complete message: "Hello ... how are you doing today?"

will now send Ack to Tx
unit now in Normal Mode
 ... ACK sent

unit now in WOR_Rx 1 second cycle Mode
will start looking for next packet

....
*/

