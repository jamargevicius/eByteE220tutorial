/*   main.cpp for project: testWORandESPwakeup
        tests ESP32 <--> eByte in Normal Mode; writes/reads a register; sends/receives data in Normal mode

    Joe Margevicius - April 2025  
*/

#include <Arduino.h>

//**************************************************************************************
//********************************* constants and assignments **************************
//**************************************************************************************
// GPIO assignments (usingUART #2 to communicate with eByte)
#define gpio_ESP_RXD2     GPIO_NUM_16
#define gpio_ESP_TXD2     GPIO_NUM_17
#define gpio_eByte_AUX    GPIO_NUM_4    // AUX line from eByte
#define gpio_eByte_M0     GPIO_NUM_32   // M0 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_eByte_M1     GPIO_NUM_33   // M1 line to eByte = RTC GPIO to preserve state later in sleep mode
#define gpio_onBoardLED   GPIO_NUM_2    // used to indicate a packet received and passed filter test
#define gpio_module_type  GPIO_NUM_15   // true for xmitter; = false for rcvr; facilitates code development

// E220 eByte registers (note - different from E22 modules)
#define REG_MODULE_ADDR_H       0x00  // specifies addr of unit ... i.e. 0x0001
#define REG_MODULE_ADDR_L       0x01

#define REG0                    0x02  // specify the following 3 "switches" in REG0
#define EBYTE_UART_RATE_9600    0x60      // default
#define EBYTE_UART_PARITY_8N1   0x00      // default
#define AIR_RATE_9600           0x04
#define REG0_Setup              EBYTE_UART_RATE_9600 | EBYTE_UART_PARITY_8N1 | AIR_RATE_9600

 // REG1 - using defaults: max RF power out = 158 mWatts  (E22 module had max = 1 Watt)
#define REG2_RF_CHAN            0x04  // = RF channel select (# 0 to #80) --- RF Freq = 850.125Mhz + 1Mhz x Chan Number (e.g. chan 4 --> freq = 854.125Mhz

#define REG3                    0x06  // needed for WOR implementation
#define WOR_CYCLE_1000MS        0x01

 // I/O commands
#define WRITE_REG_CMD           0xC0

  // data sent/received
char wakeupPacket[] = "w";  // just a short packet to wakeup the ESP32
int wakeupPacketLength = sizeof(wakeupPacket);
char TxMessage[] = "Hello ... how are you doing today?"; 
int TxMessageLength = sizeof(TxMessage);
char RxAck[] = "ACK";
int RxAckLength = sizeof(RxAck); 

// info to store in flash for wake-up
RTC_DATA_ATTR bool firstTimeUp = true;  // start true to program the devices; then false for the Rx to process packet  

//**************************************************************************************
//********************************* functions ******************************************
//**************************************************************************************
void eByteE220WriteReadMemory(byte REGtoWrite, byte contentsToWrite, int printResponse){
    // Configuration Mode to access registers: M1 M0 = 1 1 for Configuration mode
  digitalWrite(gpio_eByte_M0, HIGH);  
  digitalWrite(gpio_eByte_M1, HIGH);  
  //Serial.printf("\njust put into Config mode [1 1]: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
  delay(100);
  
  byte commandToSend[] = {WRITE_REG_CMD, REGtoWrite, 0x01, contentsToWrite};  // write to just 1 address
  Serial2.write(commandToSend, sizeof(commandToSend));

  delay(100); // delay needed to wait for eByte response and Serial2 being available
  for (int i=0; i<4; i++){
    while(!Serial2.available()){Serial.print("x"); delay(100);} // wait for a character ... WAIT HERE as a Transmitter !
    int incomingByte = Serial2.read();
    if(printResponse){Serial.print(incomingByte,HEX); Serial.print(' ');}
  }
  if(printResponse){Serial.printf(" = response. Expect (C1 %x 1 %x)", REGtoWrite, contentsToWrite);}
  
    // put back into Normal Mode: M1 M0 = 0 0 for Normal mode
  digitalWrite(gpio_eByte_M0, LOW);   
  digitalWrite(gpio_eByte_M1, LOW);   
  delay(100);  // delay 100mS after mode change 
  //Serial.printf("\nnow in Normal mode: value of M1 is %d ... value of M0 is %d\n", digitalRead(gpio_eByte_M1), digitalRead(gpio_eByte_M0));
}

void initializeDevice(){ // write to 4 registers
  Serial.print("\n ... initializing eByte - write to 4 memory locations\n");
  Serial.print("\nREG_MODULE_ADDR_H : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_H,0x01,1); // specify module addr: 0x12
  Serial.print("\nREG_MODULE_ADDR_L : "); eByteE220WriteReadMemory(REG_MODULE_ADDR_L,0x02,1); 
  Serial.print("\nREG0 : "); eByteE220WriteReadMemory(REG0,REG0_Setup,1);     // 9600 bps air rate specified (300 and 1200 not available); rest is default: serial port - 9600baud, 8N1 protocol
  Serial.print("\nREG2_RF_CHAN : "); eByteE220WriteReadMemory(REG2_RF_CHAN,0x28,1);  // specify RF chan = 0x28 = Chan 40
    // note: using defaults of REG1 and REG3 -- see A-testBasicE220Wiring for more details if interested
}
  
void blinkOnBoardLED(int numberOfBlinks){
  if (numberOfBlinks == 1){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
  else if (numberOfBlinks == 2){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200); 
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
  else if (numberOfBlinks == 3){
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200);
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW); delay(200);
    digitalWrite(gpio_onBoardLED, HIGH); delay(200); digitalWrite(gpio_onBoardLED, LOW);}
}


void putInNormal_mode(){// used by both Tx and Rx to switch from WOR to Normal ... [M1 M0] = [0 0]
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" n1 "); delay(10);} // wait for possibly still being in WOR mode
  digitalWrite(gpio_eByte_M1, LOW);
  digitalWrite(gpio_eByte_M0, LOW);
  delay(100); // delay necessary after AUX goes hi before can do anything, but check to be sure AUX is hi
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" n2 "); delay(10);} 
  Serial.println("unit now in Normal Mode");
}

void putInWOR_Tx_mode_1second(){   // [M1 M0] = [0 1] for WOR Tx
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" TxW1_1 "); delay(10);} // wait for possibly still being in WOR mode
   //Serial.println("\n\nsetup for WOR_Transmitter and 2 second WOR cycle");
  eByteE220WriteReadMemory(REG3, WOR_CYCLE_1000MS,0); // returns with [M1 M0] = [0 0]
   // enable this config: switch to WOR mode for the transmitter: M1 M0: 0 0 
   // digitalWrite(gpio_eByte_M1, LOW); // -- not necessary; M1 is already 0
  digitalWrite(gpio_eByte_M0, HIGH);
  delay(100); // delay necessary after AUX goes hi before can do anything, but check to be sure AUX is hi
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" TxW1_2 "); delay(10);} 
  Serial.println("unit now in WOR_Tx Mode 1 second cycle mode");
}

void putInWOR_Rx_mode_1second(){   // [M1 M0] = [1 0] for WOR Rx
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" RxW1_1 "); delay(10);} // wait for possibly still being in WOR mode
    //Serial.println("\n\nsetup for WOR_Receiver and 1 second WOR cycle");
  eByteE220WriteReadMemory(REG3, WOR_CYCLE_1000MS,0); // returns with [M1 M0] = [0 0]
   // enable this config: switch to WOR mode for the receover: M1 M0: 1 0 
  digitalWrite(gpio_eByte_M1, HIGH); 
   // digitalWrite(gpio_eByte_M0, LOW); // -- not necessary; M0 is already 0
  delay(100); // delay a little before continuing after a mode switch
  while((digitalRead(gpio_eByte_AUX) == 0)){Serial.print(" RxW1_2 "); delay(10);}
  Serial.printf("\nunit now in WOR_Rx 1 second cycle Mode");
}

void goToSleepESP(){
  esp_sleep_enable_ext0_wakeup(gpio_eByte_AUX,0); // Enable Ext0 as wakeup/reboot: Logic Level defined = 0 = interrupt; must do this after a reboot
   //When in deep sleep, the general GPIO hardware is turned off and float. Only the RTC part and RTC-GPIOs are on.
  gpio_hold_en(gpio_eByte_M0); // keep M0 and M1 from changing (if they change, they cause AUX to go low, and this will wake up the ESP)
  gpio_hold_en(gpio_eByte_M1);

  Serial.println("\nRECEIVER going to sleep now ... will wait for eByte's AUX line to go LOW (i.e packet detected)");
  esp_deep_sleep_start();  // ESP32 goes to sleep
}  


//**************************************************************************************
//********************************* setup ***********************************************
//**************************************************************************************
void setup() {
  Serial.begin(115200); // ESP32 programming serial port
  Serial2.begin(9600, SERIAL_8N1, gpio_ESP_RXD2, gpio_ESP_TXD2); // eByte programming serial port - powers up at 9600baud, 8N1 parity
  delay(1000); // delay for time to manually bring up terminal

  pinMode(gpio_eByte_AUX, INPUT);
  pinMode(gpio_eByte_M0, OUTPUT);
  pinMode(gpio_eByte_M1, OUTPUT);
  pinMode(gpio_onBoardLED, OUTPUT);
  pinMode(gpio_module_type, INPUT);

  digitalWrite(gpio_onBoardLED, LOW);  // start with LED off; ---> turn on and keep on if an error
  
  // **************************** RECEIVER - setup and main code*************************
  // ********* 1st time after reset or power up, program address and channel and put in WOR_RX with 1 second cycle
  // ********* after wakeup, delay a bit, then search for message
  // ************************************************************************************
  if((digitalRead(gpio_module_type) == false)){ 
    if(firstTimeUp == true){  // just configure Rx once when reset or power applied
      Serial.print("doing fullInit for Rx - 1st time only; then go to sleep awaiting a wake-up packet and msg packet");
       
      initializeDevice();  // configures address and channel; ends up in Normal mode
      putInWOR_Rx_mode_1second();  
      firstTimeUp = false;
      Serial.print("hello from firstTimeUp -- going to sleep now");
      goToSleepESP();
    }
    
    else{  // this is the normal entry point after wakeup; eByte in Rx WOR_1sec
      Serial.println("\n\nRX JUST WOKE UP by wakeup packet; now to wait for message packet");
      gpio_hold_dis(gpio_eByte_M0); 
      gpio_hold_dis(gpio_eByte_M1);
            
       // wait for the message packet (wakeup packet was just received, but ESP Serial2 port was not fully awake)     
      char incomingByteMessage[TxMessageLength] = {}; // zero the array; 
      for (int i=0; i<TxMessageLength; i++) {  
        while(!Serial2.available()){ // wait for a character ... WAIT HERE !
            Serial.print(".");
            delay(10);}
        incomingByteMessage[i] = Serial2.read();}
      Serial.printf("\n%s (received by Rx)\n", incomingByteMessage);
      
      //*********** do filtering - verify that the packet is valid ******** */
      const char *dataPointer = incomingByteMessage;
      if(strstr(dataPointer,"Hello ... how are you doing today?") != NULL){  //comparing 2 strings
        Serial.println("found complete message: \"Hello ... how are you doing today?\"");  // now blink the onBoard LED
        blinkOnBoardLED(2); // blink LED 2x to indicate a good packet was received
        
        // ********************** ACK section - RX sends ACK ***********************
        Serial.println("\nwill now send Ack to Tx");
        putInNormal_mode();  // send ACK in normal mode (less error prone)
        Serial2.write(RxAck, sizeof(RxAck));
        delay(100); //must wait until eByte gets entire word before changing modes
          // note: although the ACk is only ~400 uSec long, once a Serial2 msg is sent to eByte, 
          //  nothing can be changed in the eByte for at least 100 mSec.  
        Serial.println(" ... ACK sent");
      }
      else {
        Serial.print("packet is bad -- no ACK sent; in this test, Tx will start as if it rcvd Ack\n");
        digitalWrite(gpio_onBoardLED, HIGH);  // keep LED on ---- SYSTEM STOPS HERE; Tx waits forever
        delay(600); // equivalent delay as blinking LED 2x
      }
      
      putInWOR_Rx_mode_1second();  // put back in 1 second WOR cycle, ready to receive WOR packet from Tx
      
      firstTimeUp = false;
      delay(200);
      goToSleepESP();
    }
  }

 // TRANSMITTER setup - done once (Receiver setup done each time after wakeup)
  else if(digitalRead(gpio_module_type) == true){   // configure Transmitter into WOR mode
    Serial.print("now in tx setup");
    initializeDevice(); // configure rf address, channel, power, and serial port; ends up in Normal mode
    putInWOR_Tx_mode_1second(); // put in 1 second packet in WOR_TX mode
  }
}
      
//**************************************************************************************
//********************************* main (loop) - only Tx gets here ********************
//**************************************************************************************
void loop() {  // only Tx gets here; Rx always goes to sleep before getting here
  if(digitalRead(gpio_module_type) == true){   
    Serial.printf("\nThis is a TRANSMITTER sending wakeup packet ... now will transmit %d bytes\n", wakeupPacketLength);
    Serial2.write(wakeupPacket, sizeof(wakeupPacket));
    Serial.printf("wakeup packet sent ... now will transmit the message packet of %d bytes\n", TxMessageLength);
    
    delay(1100); // delay to wait for wakeup pkt sent in WOR_1sec
    //delay(150); // wait for Rx's Serial2 port to come alive after ESP32 wakeup
        // some notes/measurements on how long to wait for Serial2 at Receiver to stabalize before sending the 2nd "message" packet
          //delay(30); // won't work -- Serial2 port at Receiver not up yet after wakeup; can't find 2nd packet: 
          //delay(65); // works mostly, but is probably not reliable long-term. 
  
      // now send the 2nd packet = the message packet
    Serial2.write(TxMessage, sizeof(TxMessage));
    Serial.println("message sent");
    blinkOnBoardLED(1); // blink LED 1x to indicate a message packet was sent
    delay(1200); // before changing modes, wait ~1.4 seconds for the packet to go out and eByte to be quiet
    putInNormal_mode();
    
     // ********************** ACK section -- TX waits for ACK ***********************
    char incomingByteACK[RxAckLength] = {}; // zero the array; 
    for (int i=0; i<RxAckLength; i++) {  
      while(!Serial2.available()){ // wait for a character ... WAIT HERE !
          Serial.print(".");
          delay(10);}
      incomingByteACK[i] = Serial2.read();}
    Serial.printf("\n%s (received by Tx; sent from Rx after received message)\n", incomingByteACK);
    
    const char *dataPointerACK = incomingByteACK;    
    if(strstr(dataPointerACK,"ACK") != NULL){  //comparing 2 strings
      Serial.printf("\nfound ACK: %s received by Tx from Rx after received message)\n", incomingByteACK);
      blinkOnBoardLED(3);}
    else {
      delay(1000); // equivalent delay as blinking LED 3x
      Serial.printf("ACK not found: %s received by Tx from Rx after received message)\n", incomingByteACK);
    }

    putInWOR_Tx_mode_1second(); // return to WOR_1 second mode to do another transmission
    Serial.println("will wait 3 seconds before transmitting a packet again (= 1 sec LED blinking + 2 sec delay)");
    delay(1000); // delay 1 second before looping to send a message in 1sec WOR again
  }
}

//*************************************************************************************
//************* this is what should appear in the each terminal ***********************
//*************************************************************************************
/*  TRANSMITTER
now in tx setup
 ... initializing eByte - write to 4 memory locations

REG_MODULE_ADDR_H : C1 0 1 1  = response. Expect (C1 0 1 1)
REG_MODULE_ADDR_L : C1 1 1 2  = response. Expect (C1 1 1 2)
REG0 : C1 2 1 64  = response. Expect (C1 2 1 64)
REG2_RF_CHAN : C1 4 1 28  = response. Expect (C1 4 1 28)unit now in WOR_Tx Mode 1 second cycle mode

This is a TRANSMITTER sending wakeup packet ... now will transmit 2 bytes
wakeup packet sent ... now will transmit the message packet of 35 bytes
message sent
unit now in Normal Mode
........................
ACK (received by Tx; sent from Rx after received message)

found ACK: ACK received by Tx from Rx after received message)
unit now in WOR_Tx Mode 1 second cycle mode
will wait 3 seconds before transmitting a packet again (= 1 sec LED blinking + 2 sec delay)

*/

/*   RECEIVER  
REG_MODULE_ADDR_H : C1 0 1 1  = response. Expect (C1 0 1 1)
REG_MODULE_ADDR_L : C1 1 1 2  = response. Expect (C1 1 1 2)
REG0 : C1 2 1 64  = response. Expect (C1 2 1 64)
REG2_RF_CHAN : C1 4 1 28  = response. Expect (C1 4 1 28)
unit now in WOR_Rx 1 second cycle Modehello from firstTimeUp -- going to sleep now
RECEIVER going to sleep now ... will wait for eByte's AUX line to go LOW (i.e packet detected)


RX JUST WOKE UP by wakeup packet; now to wait for message packet
..............
Hello ... how are you doing today? (received by Rx)
found complete message: "Hello ... how are you doing today?"

will now send Ack to Tx
unit now in Normal Mode
 ... ACK sent

unit now in WOR_Rx 1 second cycle Mode
RECEIVER going to sleep now ... will wait for eByte's AUX line to go LOW (i.e packet detected)

*/